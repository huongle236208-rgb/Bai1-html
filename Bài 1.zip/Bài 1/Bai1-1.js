let soTienVay = parseFloat(prompt("Nhập số tiền vay (triệu đồng):"));
let laiSuat = parseFloat(prompt("Nhập lãi suất (%/năm):"));
let n = parseInt(prompt("Nhập số năm vay (n):"));

let tienLaiMotNam = soTienVay * (laiSuat / 100);
let tongTienPhaiTra = soTienVay + n * tienLaiMotNam;

alert("Số tiền cả gốc lẫn lãi phải trả sau " + n + " năm là: " + tongTienPhaiTra + " triệu đồng");